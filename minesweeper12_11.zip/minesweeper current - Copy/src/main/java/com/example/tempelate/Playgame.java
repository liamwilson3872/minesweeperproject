package com.example.tempelate;

public class Playgame {
    private boolean areyoualive;
    private int bombsremaning;
    private Tile[][] board;

    public Playgame(int amountofbombs,int sizeofgrid){
        board=new  Tile[sizeofgrid][sizeofgrid];
        areyoualive=true;
        bombsremaning=amountofbombs;
        board = new Tile[10][10];
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                board[i][j] = new Tile();
            }
        }

    }
    public void die(){
        areyoualive=false;
    }
    public boolean getareyoualive(){
        return areyoualive;
    }
    public void foundbomb(){
        bombsremaning-=1;
    }
    public void lostbomb(){
        bombsremaning+=1;
    }
    public void resetbombsfound(){
        bombsremaning=10;
    }
    public int getBombsremaning(){
        return bombsremaning;
    }
    public Tile[][] getBoard(){
        return board;
    }
    public void makebombs(int numbombs){
        for (int i=0;i<numbombs;i++){
            int rnum1=(int) (Math.random()*10);
            int rnum2=(int) (Math.random()*10);
            if (board[rnum1][rnum2].getbombstatus()==true){
                i--;
                System.out.println("double bomb. replacing");
            }else {
                board[rnum1][rnum2].changebombstatus(true);
            }
        }
    }
    public boolean isitabomb(int row,int collum){
        return  board[row][collum].getbombstatus();
    }


}
