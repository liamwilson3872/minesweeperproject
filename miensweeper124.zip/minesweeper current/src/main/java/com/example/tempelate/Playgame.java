package com.example.tempelate;

public class Playgame {
    private boolean areyoualive;
    public Playgame(){
        areyoualive=true;
    }
    public void die(){
        areyoualive=false;
    }
    public boolean getareyoualive(){
        return areyoualive;
    }



}
