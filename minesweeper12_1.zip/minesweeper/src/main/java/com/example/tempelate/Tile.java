package com.example.tempelate;

public class Tile {
    private boolean isitabomb=false;
    private int amountofbombs;

    public Tile(){
        System.out.println("Made");

    }
    public boolean getbombstatus(){
        return isitabomb;
    }
    public void changebombstatus(boolean newstatus){
        isitabomb=newstatus;
    }
    public void setAmountofbombs(int num){
        amountofbombs=num;
    }
    public int getnumofbombs(){
        return amountofbombs;
    }

}
