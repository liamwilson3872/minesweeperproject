package com.example.tempelate;

import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Background;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Paint;

import java.util.ArrayList;

public class HelloController {
    public GridPane pane;
    public Button btnclick;
    public Label lbldisplay;
    public TextField txtinput;
    private Button[][] btn=new Button[10][10];
    private Tile[][] board=new Tile[10][10];
    public void initialize(){
        board = new Tile[10][10];
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                board[i][j] = new Tile();
            }
        }

        System.out.println("click");

        for (int i=0;i<btn.length;i++){
            for (int j=0;j<btn[0].length;j++){
                btn[i][j]=new Button("");
                btn[i][j].setPrefSize(60, 60);
                pane.add(btn[i][j],j,i);
            }
        }
        makebombs(10);
        EventHandler z = new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                System.out.println(event.getSource());
                int row=GridPane.getRowIndex((Button) event.getSource());
                int colloum=GridPane.getColumnIndex((Button) event.getSource());
                System.out.println("("+row+","+colloum+")");
                checkbomb(row,colloum);
                setbombtext(board,row,colloum);


            }
        };

        for (int i=0;i<btn.length;i++){
            for (int j=0;j<btn[0].length;j++){
                btn[i][j].setOnAction(z);
            }
        }
        setbombtext(board,1,1);
        for (int i=0;i<10;i++){
            board[1][i].setAmountofbombs(2);
        }
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board.length; j++) {
                setbombtext(board,i,j);
                checkbomb(i,j);
            }
            System.out.println();
        }


    }

    public void btnclick(ActionEvent actionEvent) {

    }

    public void makebombs(int numbombs){
        for (int i=0;i<numbombs;i++){
            int rnum1=(int) (Math.random()*10);
            int rnum2=(int) (Math.random()*10);
            if (board[rnum1][rnum2].getbombstatus()==true){
                System.out.println("double bomb");
            }else {
                board[rnum1][rnum2].changebombstatus(true);
                btn[rnum1][rnum2].setText("BOMB");
            }
        }
    }
    public void checkbomb(int row,int colloum){
        if (board[row][colloum].getbombstatus()==true){
            btn[row][colloum].setText("bomb");
        }else{

        }
    }

    public void handlemakebombclick(ActionEvent actionEvent) {
        makebombs(10);
    }

    public void setbombtext(Tile[][] temp, int r, int c){
        int sum=0;
        for (int x=-1;x<=0;x++){
            for (int y=-1;y<=1;y++){
                int a=x=r;
                int b=y+c;
                if (a>=0&&a<temp.length&&b>=0&&b<temp[a].length&&!(x==0&&y==0)){
                    if (temp[a][b].getbombstatus()==true){
                        sum+=1;
                    }
                }

            }
        }
        board[r][c].setAmountofbombs(sum);
        System.out.println(sum);
        btn[r][c].setText(String.valueOf(sum));



    }
}