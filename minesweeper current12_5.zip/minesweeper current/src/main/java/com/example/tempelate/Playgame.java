package com.example.tempelate;

public class Playgame {
    private boolean areyoualive;
    private int bombsremaning;
    public Playgame(int amountofbombs){
        areyoualive=true;
        bombsremaning=amountofbombs;
    }
    public void die(){
        areyoualive=false;
    }
    public boolean getareyoualive(){
        return areyoualive;
    }
    public void foundbomb(){
        bombsremaning-=1;
    }
    public void lostbomb(){
        bombsremaning+=1;
    }
    public void resetbombsfound(){
        bombsremaning=10;
    }
    public int getBombsremaning(){
        return bombsremaning;
    }


}
